const listaTareas = document.getElementById("listaTareas");
const nuevaTareaInput = document.getElementById("nuevaTareaInput");
const agregarBtn = document.getElementById("agregarBtn");
const contador = document.getElementById("contador");

const actualizarContador = () => {
  contador.textContent = `Total de comentarios: ${listaTareas.children.length}`;
};

const agregarComentario = () => {
  const texto = nuevaTareaInput.value.trim();
  if (texto !== "") {
    const nuevaTarea = document.createElement("li");

    const textoSpan = document.createElement("span");
    textoSpan.textContent = texto;

    textoSpan.addEventListener("dblclick", () => {
      listaTareas.removeChild(nuevaTarea);
      actualizarContador();
    });

    const botonEliminar = document.createElement("button");
    botonEliminar.classList.add("icono-basura");
    botonEliminar.innerHTML = `
      <svg viewBox="0 0 448 512">
        <path d="M135.2 17.7C140.5 7.3 150.9 0 162.7 0H285.3c11.8 0 22.2 7.3 27.5 17.7L328 32H432c8.8 0 16 7.2 16 16s-7.2 16-16 16h-16.1l-20.4 403.2c-1.1 21.4-18.5 38.8-40 38.8H92.5c-21.5 0-38.9-17.4-40-38.8L32 64H16C7.2 64 0 56.8 0 48s7.2-16 16-16h104l15.2-14.3zM96.5 464h255L371 64H77l19.5 400z"/>
      </svg>
    `;
    botonEliminar.addEventListener("click", () => {
      listaTareas.removeChild(nuevaTarea);
      actualizarContador();
    });

    nuevaTarea.appendChild(textoSpan);
    nuevaTarea.appendChild(botonEliminar);
    listaTareas.appendChild(nuevaTarea);
    nuevaTareaInput.value = "";
    actualizarContador();
  }
};

agregarBtn.addEventListener("click", agregarComentario);

nuevaTareaInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    agregarComentario();
  }
});